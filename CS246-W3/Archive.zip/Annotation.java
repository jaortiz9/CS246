/**                                                                        
 * The annotation interface
 * Annotation distributes the display function to everything that needs it
 * This is annotation
 */
public interface Annotation {
   String getDisplayText();
}